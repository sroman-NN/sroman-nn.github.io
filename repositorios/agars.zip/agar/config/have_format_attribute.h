#ifndef HAVE_FORMAT_ATTRIBUTE
#define HAVE_FORMAT_ATTRIBUTE "yes"
#endif
