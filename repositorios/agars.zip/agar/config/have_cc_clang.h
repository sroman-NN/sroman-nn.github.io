#undef HAVE_CC_CLANG
