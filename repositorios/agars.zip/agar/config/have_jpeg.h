#undef HAVE_JPEG
