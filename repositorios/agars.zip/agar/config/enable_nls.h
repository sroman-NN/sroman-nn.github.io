#undef ENABLE_NLS
