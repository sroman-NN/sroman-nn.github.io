#ifndef HAVE___INT64
#define HAVE___INT64 "yes"
#endif
