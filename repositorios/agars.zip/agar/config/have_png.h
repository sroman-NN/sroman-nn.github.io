#undef HAVE_PNG
