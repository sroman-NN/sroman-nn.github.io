#ifndef HAVE_CC_ASM
#define HAVE_CC_ASM "yes"
#endif
