#ifndef HAVE_MALLOC_ATTRIBUTE
#define HAVE_MALLOC_ATTRIBUTE "yes"
#endif
