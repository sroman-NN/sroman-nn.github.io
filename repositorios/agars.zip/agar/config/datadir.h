#ifndef DATADIR
#define DATADIR "C:/Program Files (x86)/AGAR/share/agar"
#endif
