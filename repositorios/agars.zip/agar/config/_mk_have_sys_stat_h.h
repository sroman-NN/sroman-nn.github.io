#undef _MK_HAVE_SYS_STAT_H
