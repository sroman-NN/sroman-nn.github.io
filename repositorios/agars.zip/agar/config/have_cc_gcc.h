#ifndef HAVE_CC_GCC
#define HAVE_CC_GCC "yes"
#endif
