#ifndef RELEASE
#define RELEASE "Ancient Egypt"
#endif
