#ifndef PREFIX
#define PREFIX "C:/Program Files (x86)/AGAR"
#endif
