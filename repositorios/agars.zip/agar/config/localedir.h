#ifndef LOCALEDIR
#define LOCALEDIR "C:/Program Files (x86)/AGAR/share/agar/locale"
#endif
