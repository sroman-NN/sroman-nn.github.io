#ifndef TTFDIR
#define TTFDIR "C:/Program Files (x86)/AGAR/share/agar/fonts"
#endif
