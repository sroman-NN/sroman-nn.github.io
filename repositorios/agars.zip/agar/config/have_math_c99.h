#undef HAVE_MATH_C99
