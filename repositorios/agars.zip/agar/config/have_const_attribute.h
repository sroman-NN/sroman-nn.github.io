#ifndef HAVE_CONST_ATTRIBUTE
#define HAVE_CONST_ATTRIBUTE "yes"
#endif
