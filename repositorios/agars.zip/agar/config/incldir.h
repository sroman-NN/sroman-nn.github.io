#ifndef INCLDIR
#define INCLDIR "C:/Program Files (x86)/AGAR/include/agar"
#endif
