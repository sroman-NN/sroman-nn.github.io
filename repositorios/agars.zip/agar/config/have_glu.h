#undef HAVE_GLU
