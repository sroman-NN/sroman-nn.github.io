#undef HAVE_GLX
