#undef HAVE_GETUID
