#undef HAVE_DIRFD
