@echo off
echo ========================================================
echo   reparador de antena generica
echo ========================================================
echo.
echo instalando driver NDIS
pnputil /add-driver "%~dp0netrtwlanu.inf" /install

echo asignando mac en reg
powershell -NoProfile -Command ^
  "Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e972-e325-11ce-bfc1-08002be10318}' | ForEach-Object {  = Get-ItemProperty $_.PSPath; if ($p.MatchingDeviceId -like '*VID_0BDA&PID_F179*') { Set-ItemProperty $_.PSPath -Name 'NetworkAddress' -Value '02E04C818802'; Write-Host 'MAC asignada a ' $_.PSChildName } }"

echo reiniciando adaptador
powershell -NoProfile -Command ^
  "Get-NetAdapter | Where-Object { $_.InterfaceDescription -match 'Realtek.*8188' } | Restart-NetAdapter"

echo.
echo terminado sin errores (0) tu antena deberia funcionar ya correctamente de lo contrario prueba reiniciar el pc o exigir tu garantia
pause
